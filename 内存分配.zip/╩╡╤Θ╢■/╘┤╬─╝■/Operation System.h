﻿#pragma once

#define _CRT_SECURE_NO_WARNINGS 1

#include <stdio.h>
#include<malloc.h>
#include<assert.h>
typedef struct Opt{
	int _space;
	int _start;
	int _end;
	int _value;
	struct Opt *next;
}Opt;

void InitList(Opt** head);
void Optimal(Opt* head);
void First(Opt* head);
void FirstApply(Opt* head);
void Release(Opt* head);
void OptimalApply(Opt* head);
void print(Opt* head);
////////////////////////////////////////////////////////////
void InitList(Opt** head)
{
	assert(head);
	(*head) = (Opt*)malloc(sizeof(Opt));
	(*head)->next = (Opt*)malloc(sizeof(Opt));
	(*head)->next->_start = 0;
	(*head)->next->_space = 512;
	(*head)->next->_end = 512;
	(*head)->next->_value = 0;
	(*head)->next->next = NULL;
}

void OptimalApply(Opt* head)
{
	int v,i=1;
	printf("申请：");
	scanf("%d", &v);
	
	Opt* pCur = head->next;
	Opt* min = pCur;
	Opt* pPre = head;
	Opt* minPre = pPre;
	while (pCur)
	{
		while (pCur && (pCur->_space < v || pCur->_value != 0))
		{
			pPre = pCur;
			pCur = pCur->next;
		}
		if (!pCur)
		{
			if (i == 1)
			{
				printf("不能分配\n");
				return;
			}
			break;
		}
		if (i == 1)
		{
			minPre = pPre;
			min = pCur;
			i++;
		}
		if (pCur->_space < min->_space)
		{
			minPre = pPre;
			min = pCur;
		}
		pCur = pCur->next;
	}
	pCur = min;
	pPre = minPre;
	Opt* newNode = (Opt*)malloc(sizeof(Opt));
	newNode->_start = pCur->_start;
	newNode->_space = v;
	newNode->_end = newNode->_start + newNode->_space;
	newNode->_value = v;
	newNode->next = pCur;
	pCur->_start = newNode->_end;
	pCur->_space = pCur->_space - newNode->_value;
	pCur->_end = pCur->_start + pCur->_space;
	pPre->next = newNode;
}


void Optimal(Opt* head)
{
	int c;
	int count;
	printf("申请或释放次数：");
	scanf("%d", &count);
	while (count--) {
		printf("申请空间选择1，释放空间选择2：");
		scanf("%d", &c);
		switch (c)
		{
		case 1:
			OptimalApply(head);
			print(head);
			break;
		case 2:
			Release(head);
			print(head);
			break;
		default:
			break;
		}
	}
	
}

void FirstApply(Opt* head)
{
	int v;
	printf("申请：");
	scanf("%d", &v);
	Opt* pCur = head->next;
	Opt* pPre = head;
	while (pCur && (pCur->_space < v || pCur->_value != 0)) 
	{
		pPre = pCur;
		pCur = pCur->next;
	}
	if (!pCur)
	{
		printf("不可以分配\n");
		return;
	}
	Opt* newNode = (Opt*)malloc(sizeof(Opt));
	newNode->_start = pCur->_start;
	newNode->_space = v;
	newNode->_end = newNode->_start + newNode->_space;
	newNode->_value = v;
	newNode->next = pCur;
	pCur->_start = newNode->_end;
	pCur->_space = pCur->_space - newNode->_value;
	pCur->_end = pCur->_start + pCur->_space;
	pPre->next = newNode;
}

void Release(Opt* head)
{
	int v;
	printf("释放：");
	scanf("%d", &v);
	Opt* pCur = head->next;
	Opt* pPre = head;
	while (pCur->_value != v)
	{
		pPre = pCur;
		pCur = pCur->next;
		if (!pCur)
		{
			printf("没有这一块空间\n");
			return ;
		}
	}
	if (pPre->_value == 0)
	{
		pPre->_space = pPre->_space + pCur->_space;
		pPre->_end = pPre->_start + pPre->_space;
		if (pCur->next && pCur->next->_value == 0)
		{
			Opt* pNext = pCur->next;
			pPre->next = pNext;
			free(pCur);
			pPre->_space = pPre->_space + pNext->_space;
			pPre->_end = pPre->_start + pPre->_space;
			pPre->next = pNext->next;
			free(pNext);
		}
		else {
			pPre->next = pCur->next;
			free(pCur);
		}
	}
	else if (pCur->next->_value == 0) {
		Opt* pNext = pCur->next;
		pCur->_space = pCur->_space + pNext->_space;
		pCur->_value = 0;
		pCur->_end = pCur->_start + pCur->_space;
		pCur->next = pNext->next;
		free(pNext);
	}
	else
	{
		pCur->_value = 0;
	}
}

void First(Opt* head)
{
	int c;
	int count;
	printf("申请或释放次数：");
	scanf("%d", &count);
	while (count--) {
		printf("申请空间选择1，释放空间选择2：");
		scanf("%d", &c);
		switch (c)
		{
		case 1:
			FirstApply(head);
			print(head);
			break;
		case 2:
			Release(head);
			print(head);
			break;
		default:
			break;
		}
	}
	
}

void print(Opt* head)
{
	Opt* pCur = head->next;
	while (pCur)
	{
		if (pCur->_value == 0)
		{
			printf("开始：%d,空间：%d\n", pCur->_start, pCur->_space);
		}
		pCur = pCur->next;
	}
}