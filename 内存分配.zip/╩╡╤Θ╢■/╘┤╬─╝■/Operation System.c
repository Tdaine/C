﻿
#include"Operation System.h"

void menu() {
	printf("****************\n");
	printf("*1.首次适应算法*\n");
	printf("*2.最佳适应算法*\n");
	printf("****************\n");
}

void test() {
	Opt *head;
	InitList(&head);
	int c;
	menu();
	printf("请输入选择:");
	scanf("%d", &c);
	printf("\n");
	switch (c)
	{
	case 1:
		First(head);
		break;
	case 2:
		Optimal(head);
		break;
	default:
		break;
	}
}

int main() {
	test();
	system("pause");
	return 0;
}